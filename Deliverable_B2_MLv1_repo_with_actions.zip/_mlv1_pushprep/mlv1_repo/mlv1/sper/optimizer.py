import numpy as np
from typing import Callable, Dict, Any

def sper_optimize(candidates, kappa_fn: Callable[[Any], float],
                  delta_fn: Callable[[Any], float],
                  fairness_ok: Callable[[Any], bool],
                  lam: float = 0.2):
    """Toy SPER loop: select candidate maximizing E[kappa] - lam*E[Delta] s.t. fairness_ok.

    candidates: iterable of policies/hyperparams (opaque to this function)

    kappa_fn: returns coherence in [0,1]

    delta_fn: returns Delta in [0,1]

    fairness_ok: predicate enforcing JR/no-exploitation

    Returns: (best_candidate, record)

    """
    best, best_score = None, -1e9
    records = []
    for c in candidates:
        k = float(kappa_fn(c))
        d = float(delta_fn(c))
        ok = bool(fairness_ok(c))
        score = (k - lam*d) if ok else -np.inf
        rec = {"candidate": str(c), "kappa": k, "delta": d, "fair": ok, "score": score}
        records.append(rec)
        if score > best_score:
            best, best_score = c, score
    return best, records

def emit_certificate(output_path: str, decision: Dict[str, Any]):
    import json, os
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(decision, f, indent=2)
