from .metrics import total_variation, js_divergence, mmd_rbf, kappa_from_divergence
