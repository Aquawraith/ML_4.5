import numpy as np
from scipy.spatial.distance import cdist

def total_variation(p, q):
    p = np.asarray(p); q = np.asarray(q)
    p = p / p.sum(); q = q / q.sum()
    return 0.5 * np.abs(p - q).sum()

def js_divergence(p, q, eps=1e-12):
    p = np.asarray(p); q = np.asarray(q)
    p = p / (p.sum() + eps); q = q / (q.sum() + eps)
    m = 0.5*(p+q)
    def kl(a, b):
        a = np.clip(a, eps, None); b = np.clip(b, eps, None)
        return np.sum(a*np.log(a/b))
    return 0.5*kl(p,m) + 0.5*kl(q,m)

def mmd_rbf(X, Y, gamma=1.0):
    X = np.atleast_2d(X); Y = np.atleast_2d(Y)
    def rbf(A, B):
        D2 = cdist(A, B, 'sqeuclidean')
        return np.exp(-gamma * D2)
    Kxx = rbf(X, X).mean()
    Kyy = rbf(Y, Y).mean()
    Kxy = rbf(X, Y).mean()
    return Kxx + Kyy - 2*Kxy

def kappa_from_divergence(D, Dmax=1.0):
    D = max(0.0, float(D))
    Dmax = max(Dmax, 1e-12)
    kappa = 1.0 - D/Dmax
    return max(0.0, min(1.0, kappa))
