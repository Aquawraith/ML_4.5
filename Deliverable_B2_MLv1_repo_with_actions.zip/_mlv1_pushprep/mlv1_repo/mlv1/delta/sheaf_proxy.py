import numpy as np

def delta_sheaf_local_disagreement(local_sections):
    """Compute a simple proxy for sheaf gluing failure.
    local_sections: dict mapping context names to vectors over a shared index set.
    Returns: scalar Delta in [0, 1], mean pairwise disagreement normalized.
    """
    keys = list(local_sections.keys())
    if len(keys) < 2:
        return 0.0
    mats = [np.asarray(local_sections[k], dtype=float) for k in keys]
    # Normalize each to unit L1 for comparability
    mats = [m / (np.sum(np.abs(m)) + 1e-12) for m in mats]
    diffs = []
    for i in range(len(mats)):
        for j in range(i+1, len(mats)):
            diffs.append(np.mean(np.abs(mats[i] - mats[j])))
    if not diffs:
        return 0.0
    D = float(np.mean(diffs))
    return max(0.0, min(1.0, D))
