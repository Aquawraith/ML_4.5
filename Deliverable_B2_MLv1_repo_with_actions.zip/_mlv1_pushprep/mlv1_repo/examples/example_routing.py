import json, time, hashlib
import numpy as np
from mlv1.kappa.metrics import total_variation, js_divergence, kappa_from_divergence
from mlv1.delta.sheaf_proxy import delta_sheaf_local_disagreement
from mlv1.sper import sper_optimize, emit_certificate

# Toy distributions and contexts
p = np.array([0.2, 0.3, 0.5])
q_candidates = [np.array([0.21, 0.29, 0.5]), np.array([0.3, 0.2, 0.5]), np.array([0.15, 0.35, 0.5])]

def make_kappa_fn(p):
    def f(q):
        D = js_divergence(p, q)
        return kappa_from_divergence(D, Dmax=1.0)
    return f

def make_delta_fn():
    def f(q):
        local = {"U1": q, "U2": q[::-1]}
        return float(delta_sheaf_local_disagreement(local))
    return f

def fairness_ok(q):
    # Toy JR: no probability mass negative and max entry <= 0.6
    return (q >= 0).all() and (q.max() <= 0.6)

best, records = sper_optimize(q_candidates, make_kappa_fn(p), make_delta_fn(), fairness_ok, lam=0.2)

decision = {
    "version": "1.0",
    "timestamp": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    "decision": f"selected_candidate={best.tolist()}",
    "kappa": float([r for r in records if r['candidate']==str(best)][0]['kappa']),
    "delta_sheaf": float([r for r in records if r['candidate']==str(best)][0]['delta']),
    "fairness_ok": bool([r for r in records if r['candidate']==str(best)][0]['fair']),
    "constraints": {"JR": "max_prob<=0.6"},
    "kkt_multipliers": {"example": 0.0},
    "data_hash": hashlib.sha256(p.tobytes()).hexdigest(),
    "code_hash": "dev"
}
emit_certificate("artifacts/decision_certificate.json", decision)
print("Best candidate:", best)
print(json.dumps(decision, indent=2))
