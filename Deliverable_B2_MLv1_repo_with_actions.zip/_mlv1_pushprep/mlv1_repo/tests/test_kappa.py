import numpy as np
from mlv1.kappa.metrics import total_variation, js_divergence, kappa_from_divergence

def test_total_variation_basic():
    p = np.array([0.5, 0.5])
    q = np.array([0.6, 0.4])
    tv = total_variation(p, q)
    assert 0 <= tv <= 1
    assert abs(tv - 0.1) < 1e-8

def test_kappa_bounds():
    k = kappa_from_divergence(0.2, Dmax=1.0)
    assert 0.0 <= k <= 1.0
    assert abs(k - 0.8) < 1e-8

def test_js_divergence_symmetry():
    p = np.array([0.2, 0.3, 0.5])
    q = np.array([0.21, 0.29, 0.5])
    assert abs(js_divergence(p, q) - js_divergence(q, p)) < 1e-12
